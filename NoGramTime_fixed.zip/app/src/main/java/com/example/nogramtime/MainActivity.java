package com.example.nogramtime;

import android.Manifest;
import android.app.AppOpsManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/**
 * Main activity of the NoGram Time application.  This activity presents
 * a simple user interface allowing the user to select a daily usage
 * limit for Instagram and start the monitoring service.  Before
 * starting the service the activity checks that both the Usage
 * Access and overlay permissions are granted and, on Android 13+, that
 * the notification permission is granted.  If any permission is
 * missing the appropriate settings activity is opened.
 */
public class MainActivity extends AppCompatActivity {
    private Spinner spinner;
    private Button activateButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        spinner = findViewById(R.id.spinner_limits);
        activateButton = findViewById(R.id.button_activate);

        // Populate the spinner with the available limit options in minutes.
        Integer[] limits = {30, 60, 90};
        ArrayAdapter<Integer> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                limits
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        activateButton.setOnClickListener(v -> {
            // Retrieve selected limit and convert to milliseconds.
            int selectedLimit = (Integer) spinner.getSelectedItem();
            long limitMillis = selectedLimit * 60L * 1000L;
            UsageLimiter.setDailyLimit(MainActivity.this, limitMillis);

            // Check for usage stats permission.
            if (!hasUsageStatsPermission()) {
                requestUsageStatsPermission();
                return;
            }

            // Check for overlay permission.
            if (!Settings.canDrawOverlays(this)) {
                requestOverlayPermission();
                return;
            }

            // On Android 13 (API 33) and above the notification permission
            // must be granted before a foreground service can show a notification.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                if (ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(
                            this,
                            new String[]{Manifest.permission.POST_NOTIFICATIONS},
                            1001
                    );
                    // The service will be started from the permission
                    // callback once the user grants the permission.
                    return;
                }
            }

            startMonitoringService(selectedLimit);
        });
    }

    /**
     * Starts the foreground monitoring service and shows a toast to the user.
     *
     * @param selectedLimit the selected limit in minutes
     */
    private void startMonitoringService(int selectedLimit) {
        Intent serviceIntent = new Intent(MainActivity.this, ForegroundWatcher.class);
        ContextCompat.startForegroundService(MainActivity.this, serviceIntent);
        Toast.makeText(
                MainActivity.this,
                "Blocco attivato per " + selectedLimit + " minuti",
                Toast.LENGTH_SHORT
        ).show();
    }

    /**
     * Determines whether the app has been granted permission to access
     * application usage statistics.  This permission is required for
     * determining which app is currently in the foreground.
     *
     * @return true if permission is granted, false otherwise
     */
    private boolean hasUsageStatsPermission() {
        AppOpsManager appOps = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
        int mode = appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                android.os.Process.myUid(),
                getPackageName()
        );
        if (mode == AppOpsManager.MODE_DEFAULT) {
            return checkSelfPermission(Manifest.permission.PACKAGE_USAGE_STATS) == PackageManager.PERMISSION_GRANTED;
        }
        return mode == AppOpsManager.MODE_ALLOWED;
    }

    /**
     * Opens the system settings activity that allows the user to grant
     * usage access to NoGram Time.
     */
    private void requestUsageStatsPermission() {
        Toast.makeText(this, "Concedi l'accesso ai dati di utilizzo", Toast.LENGTH_LONG).show();
        Intent intent = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    /**
     * Opens the system settings activity that allows the user to grant
     * overlay permission to NoGram Time.
     */
    private void requestOverlayPermission() {
        Toast.makeText(this, "Concedi il permesso per disegnare sopra le app", Toast.LENGTH_LONG).show();
        Intent intent = new Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName())
        );
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            @NonNull String[] permissions,
            @NonNull int[] grantResults
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        // If notification permission is granted start the service.
        if (requestCode == 1001) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            if (granted) {
                int selectedLimit = (Integer) spinner.getSelectedItem();
                startMonitoringService(selectedLimit);
            } else {
                Toast.makeText(this, "Il permesso per le notifiche è necessario", Toast.LENGTH_SHORT).show();
            }
        }
    }
}