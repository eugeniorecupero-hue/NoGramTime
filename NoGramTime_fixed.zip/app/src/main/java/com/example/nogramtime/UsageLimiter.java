package com.example.nogramtime;

import android.content.Context;
import android.content.SharedPreferences;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Helper class responsible for tracking daily usage time and enforcing
 * user‑configured limits.  The time spent inside Instagram is
 * accumulated per day and persisted in SharedPreferences.  When the
 * recorded usage exceeds the configured limit the caller can decide to
 * display an overlay or otherwise block further use.  At midnight
 * (based on the device's locale) the stored usage is reset to zero
 * automatically.
 */
public class UsageLimiter {

    // SharedPreferences file name
    private static final String PREFS = "usage_limiter_prefs";
    // Keys for SharedPreferences entries
    private static final String KEY_LIMIT = "limit_millis";
    private static final String KEY_USAGE = "usage_millis";
    private static final String KEY_LAST_DATE = "last_date";

    /**
     * Stores the selected daily limit (in milliseconds) in
     * SharedPreferences.
     *
     * @param context     a Context to access SharedPreferences
     * @param limitMillis the limit to store in milliseconds
     */
    public static void setDailyLimit(Context context, long limitMillis) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        prefs.edit().putLong(KEY_LIMIT, limitMillis).apply();
    }

    /**
     * Retrieves the daily limit (in milliseconds) from SharedPreferences.
     * If no limit has been configured this will return zero.
     *
     * @param context a Context to access SharedPreferences
     * @return the stored limit in milliseconds or zero
     */
    public static long getDailyLimit(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return prefs.getLong(KEY_LIMIT, 0);
    }

    /**
     * Returns the amount of usage recorded for the current day.  If a
     * new day has started since the last recorded usage the stored
     * usage is reset to zero as a side effect.
     *
     * @param context a Context to access SharedPreferences
     * @return the accumulated usage time in milliseconds
     */
    public static long getTodayUsage(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        resetIfNewDay(prefs);
        return prefs.getLong(KEY_USAGE, 0);
    }

    /**
     * Adds the specified duration to today's accumulated usage.  If
     * called on a new day the usage will first be reset to zero.
     *
     * @param context a Context to access SharedPreferences
     * @param millis  the number of milliseconds to add
     */
    public static void addUsageTime(Context context, long millis) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        resetIfNewDay(prefs);
        long usage = prefs.getLong(KEY_USAGE, 0);
        usage += millis;
        prefs.edit().putLong(KEY_USAGE, usage).apply();
    }

    /**
     * Indicates whether the accumulated usage for today has reached or
     * exceeded the configured daily limit.
     *
     * @param context a Context to access SharedPreferences
     * @return true if the limit has been exceeded, false otherwise
     */
    public static boolean shouldBlock(Context context) {
        long limit = getDailyLimit(context);
        return limit > 0 && getTodayUsage(context) >= limit;
    }

    /**
     * Internal helper that resets the stored usage when the date
     * changes.  The date is stored in yyyyMMdd format to simplify
     * comparison.  This method must be called before reading or
     * updating the usage value.
     *
     * @param prefs SharedPreferences instance
     */
    private static void resetIfNewDay(SharedPreferences prefs) {
        String currentDate = new SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(new Date());
        String lastDate = prefs.getString(KEY_LAST_DATE, "");
        if (!currentDate.equals(lastDate)) {
            prefs.edit()
                    .putString(KEY_LAST_DATE, currentDate)
                    .putLong(KEY_USAGE, 0)
                    .apply();
        }
    }
}