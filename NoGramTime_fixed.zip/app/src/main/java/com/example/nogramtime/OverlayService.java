package com.example.nogramtime;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import androidx.annotation.Nullable;

/**
 * Service responsible for displaying a non‑dismissible full screen
 * overlay when the user has exceeded their daily Instagram usage limit.
 * The overlay covers the entire screen with a black background and
 * white message informing the user that their time on Instagram has
 * expired.  The overlay remains visible until midnight when the
 * UsageLimiter resets and the ForegroundWatcher service allows
 * Instagram to be used again.  Removing or stopping this service is
 * not exposed through the UI; the overlay can only be removed by
 * uninstalling the application or waiting until the next day.
 */
public class OverlayService extends Service {
    private WindowManager windowManager;
    private View overlayView;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        showOverlay();
        return START_STICKY;
    }

    /**
     * Adds the overlay view to the window if it isn't already present.
     */
    private void showOverlay() {
        if (overlayView != null) {
            return;
        }
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        LayoutInflater inflater = LayoutInflater.from(this);
        overlayView = inflater.inflate(R.layout.overlay, null);
        int type;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            // Deprecated but kept for compatibility on older devices.
            type = WindowManager.LayoutParams.TYPE_PHONE;
        }
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                // Prevent the overlay from receiving focus so it doesn't intercept
                // key events but still blocks touch interaction with underlying apps.
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL |
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
                        WindowManager.LayoutParams.FLAG_LAYOUT_INSET_DECOR,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.CENTER;
        try {
            windowManager.addView(overlayView, params);
        } catch (Exception e) {
            // In rare circumstances the overlay might already be added or the
            // permission revoked; catch and ignore to avoid crashing.
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        removeOverlay();
    }

    /**
     * Removes the overlay view from the window to clean up resources.
     */
    private void removeOverlay() {
        if (windowManager != null && overlayView != null) {
            try {
                windowManager.removeView(overlayView);
            } catch (Exception ignored) {
            }
            overlayView = null;
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}