package com.example.nogramtime;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

/**
 * Foreground service that periodically checks which application is in
 * the foreground and accumulates usage time if Instagram is active.
 * The service runs every few seconds (3s by default) and uses
 * UsageStatsManager to determine the last package moved to the
 * foreground.  When the configured daily limit is reached the
 * service starts the overlay service to block further use.  A
 * persistent notification is shown while this service is running to
 * comply with Android's foreground service requirements.
 */
public class ForegroundWatcher extends Service {
    private static final long INTERVAL_MS = 3000; // 3 seconds
    private static final String TARGET_PACKAGE = "com.instagram.android";
    private Handler handler;
    private Runnable monitorRunnable;
    private boolean overlayStarted = false;

    @Override
    public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());
        monitorRunnable = new Runnable() {
            @Override
            public void run() {
                // Only accumulate usage if the limit has not yet been exceeded.
                if (!UsageLimiter.shouldBlock(ForegroundWatcher.this)) {
                    String currentApp = getForegroundAppPackage();
                    if (TARGET_PACKAGE.equals(currentApp)) {
                        // Add elapsed interval to today's usage.
                        UsageLimiter.addUsageTime(ForegroundWatcher.this, INTERVAL_MS);
                        // Check again whether we've now hit the limit.
                        if (UsageLimiter.shouldBlock(ForegroundWatcher.this) && !overlayStarted) {
                            startOverlay();
                        }
                    }
                }
                // Schedule the next check.
                handler.postDelayed(this, INTERVAL_MS);
            }
        };
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Ensure the service stays in the foreground to avoid being killed.
        startForegroundServiceNotification();
        // Kick off the periodic monitoring loop.
        handler.post(monitorRunnable);
        return START_STICKY;
    }

    /**
     * Builds and displays the persistent notification required for
     * foreground services.  On API 26+ a notification channel is
     * created on the first invocation.
     */
    private void startForegroundServiceNotification() {
        final String channelId = "nogramtime_channel";
        final String channelName = "NoGram Time Monitor";
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    channelId,
                    channelName,
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Controllo del tempo di utilizzo di Instagram");
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, channelId)
                .setContentTitle("NoGram Time è attivo")
                .setContentText("Monitoraggio in corso del tempo di utilizzo di Instagram")
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW);
        startForeground(1, builder.build());
    }

    /**
     * Determines the package name of the application currently in the
     * foreground by inspecting usage events over the last several
     * seconds.  The most recent MOVE_TO_FOREGROUND or ACTIVITY_RESUMED
     * event is considered to be the active app.  This method
     * requires that the user has granted the PACKAGE_USAGE_STATS
     * permission via the Settings app.
     *
     * @return the package name of the current foreground app, or null
     */
    private String getForegroundAppPackage() {
        UsageStatsManager usm = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
        if (usm == null) {
            return null;
        }
        long endTime = System.currentTimeMillis();
        long beginTime = endTime - 1000 * 10; // look back up to 10 seconds
        UsageEvents events = usm.queryEvents(beginTime, endTime);
        UsageEvents.Event event = new UsageEvents.Event();
        String currentApp = null;
        while (events.hasNextEvent()) {
            events.getNextEvent(event);
            int type = event.getEventType();
            if (type == UsageEvents.Event.MOVE_TO_FOREGROUND ||
                    type == UsageEvents.Event.ACTIVITY_RESUMED) {
                currentApp = event.getPackageName();
            }
        }
        return currentApp;
    }

    /**
     * Starts the overlay service to block Instagram when the daily limit
     * is reached.  This flag ensures the overlay is only started once
     * per day.
     */
    private void startOverlay() {
        overlayStarted = true;
        Intent intent = new Intent(this, OverlayService.class);
        startService(intent);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(monitorRunnable);
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}